<html>
<head>
<meta charset="UTF-8">

<title> Login GJ</title>
<link rel="stylesheet" href="css_login.css" type="text/css" />
</head>
<script type="text/javascript">
function checar_caps_lock(ev) {
	var e = ev || window.event;
	codigo_tecla = e.keyCode?e.keyCode:e.which;
	tecla_shift = e.shiftKey?e.shiftKey:((codigo_tecla == 16)?true:false);
	if(((codigo_tecla >= 65 && codigo_tecla <= 90) && !tecla_shift) || ((codigo_tecla >= 97 && codigo_tecla <= 122) && tecla_shift)) {
		document.getElementById('aviso_caps_lock').style.visibility = 'visible';
	}
	else {
		document.getElementById('aviso_caps_lock').style.visibility = 'hidden';
	}
}
</script>
<body style="overflow-y: hidden;overflow-x: hidden;">

<div class="login-block">

    <h1><a href="index.php" class="login-block-title"> Clinica GJ</a></h1>
	
	<form  action="" method="post">
    <input type="text" value="" name="username" placeholder="Username" id="username"/>
    <input type="password" value="" name="password" placeholder="Password" id="password" onKeyPress="checar_caps_lock(event)" />
	<div id="aviso_caps_lock" style="visibility: hidden">
	<b>caps lock ativado</b>
	</div>
	<input type="submit" name="login" class="login-block-submit" value="Login">
	
	<center>
	<span>Ainda não se registou?</span><a href="registo.php" class="registo-text"> Registe-se agora</a>
	</center>
	</form>
	
</div>
</body>
<?php
if(isset($_POST['login']))
{
$username=$_POST["username"];
$password=$_POST["password"];
 
//liga e escolhe a BD
include("ligaBD.php");
 if($username=="admin"&& $password=="admin123")
 {
	 header("Location:pag_admin.php");
 }
 else
 {
	//verifica se usename/password existem na BD
	$existe="select * from dados where username='".$username."'and password='".$password."' and oculto=0";
	$faz_existe=mysqli_query($ligaBD,$existe);
	$num_registos=mysqli_num_rows($faz_existe);
 
	if($num_registos==1){
		$registos=mysqli_fetch_array($faz_existe);
		session_start();
		$_SESSION["nome"]=$registos["nome"];
		header("Location:index.php");
   
	}
	else{
    
		echo"<script> alert('Login ou senha incorreta')</script>";
	}
 }
 
}
 
?>
</html>