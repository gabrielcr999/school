<html>
<head>
<meta charset="UTF-8">

<title> Admin GJ</title>
<link rel="stylesheet" href="css_Admin.css" type="text/css" />
</head>
	<body>
	<div class="header">
		<div class="logo"> <img src="img/clinicagj.gif" border="0" width="245" height="80"> </div>
		</div>
	</div>
	<a href="pag_admin.php">
		<div class="user">
		Listar Utilizadores
		</div>
	</a>
	
		<a href="recuperar.php">
		<div class="recuperar_users">
		Recuperar Utilizadores
		</div>
	</a>
		</a>
		<a href="index.php">
		<div class="logout">
		Logout
		</div>
	</a>
	<div class="img-user">
	
	<b>Olá,Admistrador</b>
	
	<img class="user1" src="img/img-user.png" border="0" width="80" height="60">
	
	</div>
	<div class="conteudo">
	
	
	<br><br>
	<?php
if(!isset($_POST["ordenar"])){
	$ordenar="nome";
}
else{
	$ordenar=$_POST["ordenar"];
	
}
if($ordenar=='nome')
{
	$ordenar_por="order by nome";
	
}

if($ordenar=='email')
{
	$ordenar_por="order by email";
	
}
if($ordenar=='username')
{
	$ordenar_por="order by username";
	
}


include("ligaBD.php");

$lista ="select * from dados where oculto=0 $ordenar_por";
$faz_lista= mysqli_query($ligaBD,$lista);
$num_registos=mysqli_num_rows($faz_lista);

if($num_registos==0)
{
	echo"<script> alert('Não existem, registos para listar')</script>";
	exit;
}
else
	echo "N. total de registos:".$num_registos;

?>
<table border ="0">
<tr><th width="250">Nome</th><th width="300">Email</th><th width="250">Telefone</th><th width="250">Username</th><th width="250">Password</th><th width="180" ></th></tr>

<?php
for($i=0; $i<$num_registos; $i++)
{
	$registos=mysqli_fetch_array($faz_lista);
	echo'<tr>';
	echo'<td>'.$registos['nome'].'</td>';
	echo'<td>'.$registos['email'].'</td>';
	echo'<td>'.$registos['telefone'].'</td>';
	echo'<td>'.$registos['username'].'</td>';
	echo'<td>'.$registos['password'].'</td>';
	echo'<td> <a href="editar.php?email='.$registos['email'].'">Editar</a>|<a href="ocultar.php?email='.$registos['email'].'">Ocultar</a></td>';
	echo'</tr>';
}
?>

</table>
<form method ="POST" name="form1">

<b> Ordenar por:<select name="ordenar" onchange="javascript:form1.submit();">
<option value="nenhum" SELECTED></option>
  <option value="nome">Nome</option>
  <option value="email">Email</option>
  <option value="username">Username</option>
  
  
</select>


</form>
</div>
	<?php
	include("footer.php");
	?>
	</body>

</html>