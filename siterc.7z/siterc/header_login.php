<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Clinica GJ</title>
<link rel="stylesheet" href="css_header.css" type="text/css" />
</head>

<body>

<div id="header">

<div class="logo"> <img src="img/clinicagj.gif" border="0" width="245" height="80"> </div>
</div>
<a href="index.php" >
	<div class="btn_home1"> <b>Home</b>
	</div>
</a>
<a href="servicos.php">
	<div class="btn_especialidade">Serviços
	</div>
</a>

<a href="contactos.php">
	<div class="btn_Contacto">Contacto
	</div>
</a>
<a href="logout.php">
	<div class="btn_login">
		<?php 
			echo $_SESSION["nome"];
			echo"  (Sair)";
		?>
		
		
	</div>

</a>
<a href="https://pt-pt.facebook.com/">
<div class="fb">
<img src="img/fb.png" width="50" height="50">
</div>
</a>

<a href="https://twitter.com/">
<div class="twitter">
<img src="img/Twitter.png" width="40" height="40">
</div>
</a>
<a href="https://www.instagram.com/">
<div class="instagram">
<img src="img/Instagram.png" width="60" height="60">
</div>
</a>

</body>
</html>