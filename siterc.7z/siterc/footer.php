<html>
<title>Clinica GJ</title>
<link rel="stylesheet" href="css_footer.css" type="text/css" />
	<body>
		<div class="poch">
			<img src="img/poch.jpg" width= 328px , height= 76px;>
		</div>
		<div class="copy">© 
		<?php
		$date = date('Y');
		echo $date;?>
		 Clinica GJ | Todos Direitos Reservados | Criado por:<a href="https://www.facebook.com/profile.php?id=100000708660258" class="autor"><b> Gabriel Silva </b></a> & <a href="https://www.facebook.com/jimmy.fernandes.906" class="autor"><b> Jimmy Fernandes </b></a>
		
		</div>

	</body>
</html>
