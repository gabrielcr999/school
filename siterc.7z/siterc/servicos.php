<html>
<header>
<meta charset="UTF-8">
<title>Serviços GJ</title>
<link rel="stylesheet" href="css_servicos.css" type="text/css" />
</header>
<body>
<?php
$nome="servicos";
include("header.php");
?>
<div class="servicos">

<h1>Especialidades</h1>
<div class="texto">
<p>Cirurgia Geral</p>
<p>Cirurgia Oncológica</p>
<p>Cirurgia Plástica e Reconstrutiva</b>
<p>Neurocirurgia</p>
<p>Cirurgia Maxilo-Facial</b>
<p>Medicina Interna</p>
<p>Endocrinologia</p>
<p>Consulta do Fígado, Vesícula e Vias Biliares</p>
<p>Cirurgia Vascular (varizes)</p>
<p>Oncologia Médica</p>
<p>Cardiologia</p>
<p>Ginecologia e Obstetrícia</p>
<p>Medicina Dentária</p>
<p>Implantologia</p>
<p>Protésico Dentário</p>
<p>Ortodontia</p>
<p>Periodontologia</p>
<p>Enfermagem</p>
</div>
</div>
<div class="estetica">
<h1>Medicina Estética</h1>
<div class="text">
<p>Botox</p>
<p>Depilação Laser</p>
<p>Ácido Hialurónico</b>
<p>Peelings</p>
<p>Programas de Emagrecimento</b>
<p>Tratamentos Médicos de Celulite </p>
<p>Tratamentos Médicos de Flacidez</p>
<p>Terapia por Ondas acústicas</p>
<p>Mesoterapia</p>
<p>Cirurgia Plástica e Reconstrutiva</p>
</div>
</div>
<div class="exames">
<div class="texto">
<h1>Exames</h1>
<p>Análises Clínicas</p>
<p>Ecografia</p>
<p>Electrocardiograma</b>
<p>Ecocardiograma</p>
<p>Ecodoppler</b>
<p>MAPA</p>
<p>Holter</p>
<p>Prova de Esforço</p>
<p>Electromiografia</p>
<p>Citologias</p>
<p>Estudos Auditivos</p>
<p>Laringoscopia e Rinuscopia</p>

</div>
</div>

<?php


include("footer.php");

?>


</body>
</html>