<html>
<head>
<meta charset="UTF-8">

<title>Contactos GJ</title>
<link rel="stylesheet" href="css_contactos.css" type="text/css" />
 
	<body>
	<?php
	$nome="contactos";
	
	include("header.php");
	$erros=0;
	?>
	
	<div class="contactos">
	
	<form action=""  method="POST">
	<div id"verificar">
	<?php
		if(isset($_POST['Enviar']))
		{
			$nome= $_POST["nome"];
			if(empty($nome))
			{
				$erros=1;
			echo "Nome inválido<br>";
			}
		}
	?>
    <input type="text"  name="nome" placeholder="Nome" id="username"/>
	<div id"verificar">
	<?php
		if(isset($_POST['Enviar']))
		{
			$email= $_POST["email"];
			if ( ( ! isset( $email ) || ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) ) 
			{
				$erros=1;
				echo"Email inválido.";
			}
		}
	?>
	
	</div>
    <input type="text" value="" name="email" placeholder="Email" id="password"/>
	
	</div>
	
	<?php
	
	if(isset($_POST['Enviar']))
		{
			$telefone= $_POST["telefone"];
			if(empty($telefone))
			{
				$erros=1;
			echo "Telefone inválido";
			
			}
		}
	?>

	<input type="text" value="" name="telefone" maxlength="9" placeholder="Telefone"  id="password"/>
	<div id"verificar">
	<?php
	if(isset($_POST['Enviar']))
		{
			$comentario= $_POST["comentario"];
			if(empty($comentario))
			{
				$erros=1;
			echo "Comentario inválido";
			}
			
		}
		?>
		</div>
	
	<textarea id="msg" cols=10 rows=10 name="comentario" placeholder="Seu comentário..." ></textarea><br>
	
	<input type="submit"  class="contacto-submit" value="Enviar" name="Enviar">
	</div>
	
	<div class="informacao">
	<h1>Informação de contacto</h1>
		<b id="boll">Morada:</b>
		 Av. Dr. Lourenço Peixinho, n.º18, 5º, Sala PQ - 3800-159 Viseu<br><br>
		<b id="boll">Telefone:</b> 234 481 690<br><br>
		<b id="boll">Telemovel:</b> 961 767 528 <br><br>
		<b id="boll">Email:</b> geral@clinicagj.pt<br><br>
	</div>
	<div class="linha">
		</div>
	<?php
	if(isset($_POST["Enviar"]))
	{
	if($erros==0)
	{
		echo"<script> alert('A sua mensagem foi enviada')</script>";
	}
	}
	?>
	<?php
	include("footer.php");
	?>

	</body>
	
</html>