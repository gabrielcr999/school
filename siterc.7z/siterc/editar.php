<html>
<body>
<?php
$email=$_GET['email'];
include("ligaBD.php");
$editar="select * from dados where email='".$email."'";
$faz_editar=mysqli_query($ligaBD,$editar);
$registos=mysqli_fetch_array($faz_editar);
?>

<link rel="stylesheet" href="css_Admin.css" type="text/css" />
</head>
	<body>
	<div class="header">
		<div class="logo"> <img src="img/clinicagj.gif" border="0" width="245" height="80"> </div>
		</div>
	</div>
	<a href="pag_admin.php">
		<div class="user">
		Listar Utilizadores
		</div>
	</a>
	
		<a href="">
		<div class="recuperar_users">
		Recuperar Utilizadores
		</div>
	</a>
		</a>
		<a href="index.php">
		<div class="logout">
		Logout
		</div>
	</a>
	<div class="img-user">
	
	<b>Olá,Admistrador</b>
	
	<img class="user1" src="img/img-user.png" border="0" width="80" height="60">
	
	</div>
<div class="editar">
<form action="atualizardados.php?email=<?php echo $email;?>" method="POST">
<b>Nome:</b><input type="text" name="nome" value= "<?php echo $registos["nome"];?>"><br>
<b>Telefone:</b><input type="text" name="telefone"value="<?php echo $registos["telefone"];?>"><br>
<b>Password:</b><input type="text" name="password"value="<?php echo $registos["password"];?>"><br>
<input class="editar-submit" type="submit"  name="editar" value="Editar"><br>
</div>
</form>
<?php
include("footer.php");
?>
</body>
</html>