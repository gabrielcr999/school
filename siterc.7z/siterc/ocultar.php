<html>
<body>

<?php
$email=$_GET['email'];
//---------------------------------------------------------
include("ligaBD.php");
//---------------------------------------------------------
$ocultar = "select * from dados where email='$email'";


//---------------------------------------------------------
$ocultar="update dados set oculto = 1 where email='$email'";
$fazer = mysqli_query($ligaBD, $ocultar);


if($fazer)
{	
	header("Location:pag_admin.php");
	
	
}


?>

<a href="pag_admin.php">Voltar </a>
</body>
</html>