<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Clinica GJ</title>
<link rel="stylesheet" href="css_index.css" type="text/css" />
</head>
<body>

<?php
include("ligaBD.php");
session_start();
if(!isset($_SESSION["nome"]))
{
	include("header.php");
}
else
{
	include("header_login.php");
}

	
?>

<div id="posicao">
     
    <div id="img">  
   	
        <img src="img/img1.jpg" id="slideshow"><br/>
    	</div>
       
    

<script type="text/javascript" src="java_rotativo.js"> </script>
</div>

<div class="noticias_topo_box"><b>Notícias</b></div>

<div class="noticias_box1">

<b><br> <center>Dr. João Paulo Tondela  foi galardoado</b></center><br>
&nbsp No dia 20 de Janeiro de 2016, o nosso médico  Dr. João Paulo Tondela  foi galardoado pela Associação Europeia de Osseointegração (EAO), uma das mais reconhecidas Organizações cientificas internacionais .



</div>
<div class="quemsomos_topo_box">
<b>Quem Somos?</b>
</div>
<div class="quemsomos_box1">
<br>&nbsp A Clinica GJ foi criada em 2000 e é um dos maiores grupos de prestação de cuidados de saúde em termos de rendimentos no mercado português.<br>
<br>&nbsp Em fevereiro de 2014, tornou-se a primeira empresa privada do setor da Saúde cotada em bolsa. Em outubro de 2014, a seguradora portuguesa Fidelidade adquiriu 96% das ações da empresa, passando assim a ser o novo acionista maioritário da Clinica GJ.

</div>
<div class="ondeestamos_topo_box">
<b>Onde Estamos?</b>
</div>
<div class="ondeestamos_box1">
<iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d96837.27754783006!2d-7.923172408862613!3d40.67033496040804!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0xd23364efce139bb%3A0xe456f253870748dd!2sesenviseu!3m2!1d40.6607206!2d-7.9077208!5e0!3m2!1spt-PT!2spt!4v1453929048974" width="365" height="180" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>



<?php
include("footer.php");
?>
</body>
</html>