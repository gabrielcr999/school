<html>
<head>
<meta charset="UTF-8">

<title> Registo GJ</title>
<link rel="stylesheet" href="css_registo.css" type="text/css" />
</head>

<body style="overflow-y: hidden;overflow-x: hidden;">

<div class="registo-block">
<center>
    <h1><a href="index.php" class="registo-block-title">Clinica GJ</a></h1>
	</center>
	<form  action="" method="post">
	<?php
	$erros=0;
	if(isset($_POST['registar']))
		{
			$nome= $_POST["nome"];
			if(empty($nome))
			{
			echo "<b>Nome inválido</b>";
			$erros=1;
			}
		}
	?>
	<input type="text" value="" name="nome" placeholder="Nome" />
	<?php
		if(isset($_POST['registar']))
		{
			$email= $_POST["email"];
			if ( ( ! isset( $email ) || ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) ) 
			{
				echo"<b>Email inválido.<b>";
				$erros=1;
			}
		}
	?>
	
	<input type="email" value="" name="email" placeholder="Email"/>
	<?php
	if(isset($_POST['registar']))
		{
			$telefone= $_POST["telefone"];
			if(empty($telefone))
			{
			echo "<b>Telefone inválido.</b>";
			$erros=1;
			}
		}
	?>
	
	<input type="text" value="" name="telefone" maxlength="9" placeholder="Telefone"/>
	<?php
	if(isset($_POST['registar']))
		{
			$username= $_POST["username"];
			if(empty($username))
			{
			echo "<b>Username inválido</b>";
			$erros=1;
			}
		}
	?>
	
    <input type="text" value="" name="username" placeholder="Username" />
	<?php
	if(isset($_POST['registar']))
		{
			$password= $_POST["password"];
			if(empty($password))
			{
				echo "<b>Password inválida</b>";
			$erros=1;
			}
		}
	?>
	
    <input type="password" value="" name="password" placeholder="Password"/>
	
	<input type="password" value="" name="password1" placeholder="Confirmar Password"/>
<?php
if(isset($_POST["registar"])& $erros==0)
{
$email=$_POST["email"];
$nome=$_POST["nome"];
$telefone=$_POST["telefone"];
$username=$_POST["username"];
$password=$_POST["password"];
$confirmarpassword=$_POST["password1"];

//verificar se as passwords são iguais antes de prosseguir
if ($password!=$confirmarpassword){
	echo"<script> alert('As passwords tem que ser iguais!')</script>";
	
}
else
{

//Ligar e selecionar a Base de Dados escola
include("ligaBD.php");

//Início de ação sobre a Base de Dados
$existe="select * from dados where email='".$email."'or username='".$username."'"; //Verifica em todos os campos da tabela aluno se há registos com email ou username
$faz_existe=mysqli_query($ligaBD,$existe); //Questão à Base de Dados
$jaexiste=mysqli_num_rows($faz_existe);//Conta o número total de resultados devolvidos por uma Query à BD

//Início de verificação se aluno já registado
 if($jaexiste==0){
	//Inserir dados na tabela aluno
	$insere_aluno="insert dados values('".$nome."','".$email."','".$telefone."','".$username."','".$password."','0')";
	//Processa a Query junto da Base de Dados
	$faz_insere_aluno=mysqli_query($ligaBD,$insere_aluno);
	echo "<script> alert('Foi registado com sucesso!'); window.location.href='login.php';</script>";
	
	
}
else
	echo"<script> alert('Já se encontra registado!')</script>";
}
}
?>

	<input type="submit" name="registar" class="registo-block-submit"  value="Registar">
	</form>
</div> 
</body>

</html>