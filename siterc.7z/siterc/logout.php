<?php
session_start();
unset ($_SESSION["nome"]);

	echo "<script> alert('Sessão terminada!'); window.location.href='index.php';</script>";




 
?>