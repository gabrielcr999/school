<?php
$email=$_POST["email"];
$nome=$_POST["nome"];
$telefone=$_POST["telefone"];
$username=$_POST["username"];
$password=$_POST["password"];
$confirmarpassword=$_POST["password1"];

//verificar se as passwords são iguais antes de prosseguir
if ($password!=$confirmarpassword){
	echo "<p>As passwords devem ser iguais!";
	exit;
}

//Ligar e selecionar a Base de Dados escola
include("ligaBD.php");

//Início de ação sobre a Base de Dados
$existe="select * from dados where email='".$email."'or username='".$username."'"; //Verifica em todos os campos da tabela aluno se há registos com email ou username
$faz_existe=mysqli_query($ligaBD,$existe); //Questão à Base de Dados
$jaexiste=mysqli_num_rows($faz_existe);//Conta o número total de resultados devolvidos por uma Query à BD

//Início de verificação se aluno já registado
if($jaexiste==0){
	//Inserir dados na tabela aluno
	$insere_aluno="insert dados values('".$email."','".$nome."','".$telefone."','".$username."','".$password."','0')";
	//Processa a Query junto da Base de Dados
	$faz_insere_aluno=mysqli_query($ligaBD,$insere_aluno);
	echo "<p>O aluno foi registado com sucesso!";
}
else
	echo"<p>O aluno já se encontra registado!";
?>