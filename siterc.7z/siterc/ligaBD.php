<?php
// Estabelece a ligação a Base de Dados	
$ligaBD=mysqli_connect("localhost","gabriel","123");
//Verificação de erros
if(!$ligaBD)
{
	echo "<br> Erro: Não foi possivel estabelecer ligação com a Base de Dados"; exit;
}
//selecionar a Base de Dado
$escolheBD=mysqli_select_db($ligaBD,"escola");
//Verificação de erros
if(!$escolheBD)
{
	echo "<br> Erro: Ao escolher Base de Dados"; exit;
}
mysqli_query($ligaBD, "SET NAMES utf8");
?>