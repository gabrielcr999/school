var images = ["img/img1.jpg","img/img2.jpg","img/img4.jpg","img/img5.jpg","img/img6.jpg"];

var imgNum = 0;
var imgLength = images.length - 1;


function changeImage(direction) {
    imgNum = imgNum + direction;
    if (imgNum > imgLength) {
        imgNum = 0;
    }
    if (imgNum < 0) {
        imgNum = imgLength;
    }
    document.getElementById('slideshow').src = images[imgNum];
    return false; 
}
window.setInterval(function() {
    changeImage(1);
}, 5000);