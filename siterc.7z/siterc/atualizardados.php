<?php


$email=$_GET["email"];
$nome=$_POST["nome"];
$telefone=$_POST["telefone"];
$password=$_POST["password"];

include("ligaBD.php");

$atualizar="update dados set nome='".$nome."',telefone='".$telefone."', password='".$password."' where email='".$email."'";
$faz_atualizar=mysqli_query($ligaBD,$atualizar);
if($faz_atualizar)
	
	header("Location:pag_admin.php");




?>
